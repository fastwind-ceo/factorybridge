# Agent Rules

- No coding before explicit user command.
- Use ProjectCapsule as canonical source of truth.
- Keep AI assists / Human approves principle.
- Preserve RBAC and file security requirements.
