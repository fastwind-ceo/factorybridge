# CHANGELOG

## 2026-05-13
- Created complete planning Word package.
- Completed PDV and mass runs report.
- Formed ProjectCapsule structure.
