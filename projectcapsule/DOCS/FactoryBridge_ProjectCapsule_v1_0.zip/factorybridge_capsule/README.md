# FactoryBridge by Fast Wind

Status: PLANNING_PACKAGE_READY / WAITING_FOR_USER_COMMAND_TO_DEVELOP

This capsule contains the complete Word planning package, PDV report, mass run results and updated master plan.
